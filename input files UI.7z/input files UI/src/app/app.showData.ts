import { Component } from '@angular/core';

@Component({
  selector: 'show-data',
  templateUrl: `app/app.showData.html`,
})

export class showData  { 

 }