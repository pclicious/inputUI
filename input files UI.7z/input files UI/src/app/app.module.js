"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
// import { CustomFormsModule } from 'ng2-validation';
var app_input_1 = require("./app.input");
var app_control_1 = require("./app.control");
var app_output_1 = require("./app.output");
var app_component_1 = require("./app.component");
var router_1 = require("@angular/router");
// import { parse, format, AsYouType } from 'libphonenumber-js'
var app_showData_1 = require("./app.showData");
var appRoutes = [
    { path: 'Input', component: app_input_1.Appinput },
    { path: 'Control', component: app_control_1.Appcontrol },
    { path: 'Output', component: app_output_1.Appoutput },
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, router_1.RouterModule.forRoot(appRoutes)],
        declarations: [app_component_1.AppComponent, app_input_1.Appinput, app_control_1.Appcontrol, app_output_1.Appoutput, app_showData_1.showData],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map