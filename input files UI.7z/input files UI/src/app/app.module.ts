import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
// import { CustomFormsModule } from 'ng2-validation';
import { Appinput }   from './app.input'
import { Appcontrol } from './app.control'
import { Appoutput } from './app.output'
import { AppComponent }  from './app.component';
import { RouterModule, Routes } from '@angular/router';
// import { parse, format, AsYouType } from 'libphonenumber-js'
import { showData } from './app.showData'


 const appRoutes: Routes = [
    { path: 'Input', component: Appinput },
    { path: 'Control', component: Appcontrol },
    { path: 'Output', component: Appoutput },
 ];


@NgModule({
  imports:      [ BrowserModule,FormsModule, RouterModule.forRoot(appRoutes)],
  declarations: [ AppComponent,Appinput,Appcontrol,Appoutput,showData ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
