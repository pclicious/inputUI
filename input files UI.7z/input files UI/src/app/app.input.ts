import { Component } from '@angular/core';
import * as saveAs from 'file-saver'

@Component ({
   selector: 'my-app',
   templateUrl: `app/app.input.html`,
})
export   class   Appinput  {
    // textValue = '';
    savetext ='';
    filename = 'input.txt';
    
    
     

   
  clearAll(){
    this.textValue = '';
    this.savetext = '';
  }

  saveText(value: string){
    this.savetext = this.textValue;
    if (this.savetext!==''){
      var file = new File([this.savetext], "input.txt", {type: "text/plain;charset=utf-8"});
      saveAs(file);
      this.textValue='';
    } 
    else{
      alert("Cannot save empty file.");
    }
  }
}